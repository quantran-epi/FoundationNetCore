define("epi-cms/contentediting/move-behind-overlay", [], function () {
    // summary:
    //      Moves element behind the overlay
    // tags:
    //      internal

    return function moveBehindOverlay(elToMove, overlayPosition) {
        var elPosition = elToMove.getBoundingClientRect();

        // top, bottom
        if (elPosition.top < overlayPosition.top) {
            elToMove.style.top = overlayPosition.top + "px";
        } else if (elPosition.bottom > overlayPosition.bottom) {
            elToMove.style.top = (overlayPosition.bottom - elPosition.height) + "px";
        }

        // left, right
        if (elPosition.left < overlayPosition.left) {
            elToMove.style.left = overlayPosition.left + "px";
        } else if (elPosition.right > overlayPosition.right) {
            elToMove.style.left = (overlayPosition.right - elPosition.width) + "px";
        }
    };
});
